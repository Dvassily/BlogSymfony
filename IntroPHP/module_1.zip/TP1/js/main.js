$(document).ready(function() {
    "use strict";

    //$.ema();
});
