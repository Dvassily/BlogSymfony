(function ($) {
    "use strict";
    
}(jQuery));
