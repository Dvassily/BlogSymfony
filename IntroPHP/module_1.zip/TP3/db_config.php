<?php

$dbDriver = 'mysql';
$dbHost = 'localhost';
$dbName = 'chuck';
$dbUser = 'root';
$dbPwd = '';
